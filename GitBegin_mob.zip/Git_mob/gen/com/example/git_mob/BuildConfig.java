/** Automatically generated file. DO NOT MODIFY */
package com.example.git_mob;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}