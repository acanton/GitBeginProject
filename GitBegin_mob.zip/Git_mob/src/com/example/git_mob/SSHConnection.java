package com.example.git_mob;

import android.os.AsyncTask;

import com.jcraft.jsch.*;

import java.awt.*;
import java.io.*;
import java.util.concurrent.*;

public class SSHConnection extends AsyncTask<Void, Void, Void>{

	public SSHConnection() {
		// TODO Auto-generated constructor stub
	}



	@Override
	protected Void doInBackground(Void... params) {
		// TODO Auto-generated method stub
		return null;
	}

}
