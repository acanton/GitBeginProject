﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LibGit2Sharp;

namespace GitBegin
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			this.InitializeComponent();
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}

		private void Button_Mouse_Enter(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: Add event handler implementation here.
		}
		private void Go_To_MainMenuGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
        private void Create_Repo(object sender, System.Windows.RoutedEventArgs e)
        {
            string rootedPath = Repository.Init("C:\\mytestrepo2", true);

            Console.WriteLine(rootedPath);  
        }
		private void Go_To_CommitHistoryGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Visible;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositoryCreationGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Visible;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositorySelectGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Visible;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_CommitGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Visible;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_LoginGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Visible;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_PullGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Visible;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_OpenRepoGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Visible;
		}
		private void Go_To_RepositoryMainGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Visible;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
	}
}