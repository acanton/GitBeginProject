﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NGit;
using NGit.Api;
using NGit.Transport;
using AutoItX3Lib;
using System.Diagnostics;


namespace GitBegin
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
    /// 
    
	public partial class MainWindow : Window
	{
        string activeRepoPath = "";
        NGit.Api.Git repository;
        string activeURI = "";
        AutoItX3 autoIt = new AutoItX3();

		public MainWindow()
		{
			this.InitializeComponent();
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
		}

		private void Button_Mouse_Enter(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: Add event handler implementation here.
		}
		private void Go_To_MainMenuGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
		}
        private void Clone_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            //string rootedPath = Repository.Init(path + "\\" + name, bareRepo);
            var credentials = new UsernamePasswordCredentialsProvider("michael4243", "surprises0");
            activeRepoPath = FolderPathTextBox3.Text;
            // Or globally as the default for each new command
            CredentialsProvider.SetDefault(credentials);
            // Let's clone the NGit repository
            var clone = Git.CloneRepository()
                .SetDirectory(@activeRepoPath)
                .SetURI(activeURI);

            // Execute and return the repository object we'll use for further commands
            repository = clone.Call();
            //Console.WriteLine(rootedPath);
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void openActivePath()
        {
            checkTerminal();
            autoIt.WinActivate("Administrator: C:\\Windows\\system32\\cmd.exe");
            wait(10);
            string cmd = "cd " + activeRepoPath;
            autoIt.Send(cmd + "\r");
            autoIt.WinActivate("MainWindow");
        }
        private void Open_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            if (true)
            {
                activeRepoPath = FolderPathTextBox4.Text;
                openActivePath();
            }
            else
            {
                string s = RepoNameTextBox1.Text + ".git";
                activeURI = s;
                var credentials = new UsernamePasswordCredentialsProvider("michael4243", "surprises0");

                // Or globally as the default for each new command
                CredentialsProvider.SetDefault(credentials);
            }
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void checkTerminal()
        {
            if (autoIt.WinExists("Administrator: C:\\Windows\\system32\\cmd.exe") == 0)
            {
                System.Diagnostics.Process.Start("C:\\Windows\\system32\\cmd.exe");
            }
        }
        private void wait(int millis)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            while (true)
            {
                if (stopwatch.ElapsedMilliseconds >= millis)
                {
                    break;
                }
                System.Threading.Thread.Sleep(1);
            }
        }
        private void Create_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            activeRepoPath = FolderPathTextBox.Text;
            bool bareRepo = (bool)BareRepo.IsChecked;
            if (true)
            {
                checkTerminal();
                autoIt.WinActivate("Administrator: C:\\Windows\\system32\\cmd.exe");
                string cmd = "git init";
                if (bareRepo)
                    cmd += " --bare";
                autoIt.WinWaitActive("Administrator: C:\\Windows\\system32\\cmd.exe");
                autoIt.Send("mkdir " + activeRepoPath + "\r");
                autoIt.Send("cd " + activeRepoPath + "\r");
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            }
            else
            {           
                activeURI = activeRepoPath;
                if (bareRepo == null)
                    bareRepo = false;
                //Create_Repo(FolderPathTextBox.Text, RepoNameTextBox.Text, bareRepo);

                var clone = Git.Init()
                    .SetDirectory(@activeRepoPath)
                    .SetBare(bareRepo);

                // Execute and return the repository object we'll use for further commands
                repository = clone.Call();
            }
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void Commit_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            
            var author = new PersonIdent("Michael", "mkell49@lsu.edu");
            string message = FolderPathTextBox1.Text;

            if (true)
            {
                checkTerminal();
                autoIt.WinActivate("Administrator: C:\\Windows\\system32\\cmd.exe");
                wait(10);
                string cmd = "git commit -m \"" + activeRepoPath +"\"";
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            } else {
            var commit = repository.Commit()
                .SetMessage(message)
                .SetAuthor(author)
                .SetAll(true) // This automatically stages modified and deleted files
                .Call();

            // Our new commit's hash
            var hash = commit.Id;
            //using (var repo = new Repository(activeRepoPath))
            //{

                // Create the committer's signature and commit
                //Signature author = new Signature("Default User", "email@email.com", DateTime.Now);
                //Signature committer = author;
                   
                // Commit to the repository
                //Commit commit = repo.Commit(message, author, committer);
            //}
            }

        }

        private void Push_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            if (true)
            {
                checkTerminal();
                autoIt.WinActivate("Administrator: C:\\Windows\\system32\\cmd.exe");
                wait(10);
                string cmd = "git push";
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            }
            else
            {
                var push = repository.Push().Call();
            }
        }
        private void Go_To_FileViewerGrid(object sender, System.Windows.RoutedEventArgs e)
        {
            FileViewerGrid.Visibility = Visibility.Visible;
            MainMenuGrid.Visibility = Visibility.Hidden;
            CommitHistoryGrid.Visibility = Visibility.Hidden;
            RepositoryCreationGrid.Visibility = Visibility.Hidden;
            RepositorySelectGrid.Visibility = Visibility.Hidden;
            CommitGrid.Visibility = Visibility.Hidden;
            LoginGrid.Visibility = Visibility.Hidden;
            PullGrid.Visibility = Visibility.Hidden;
            RepositoryMainGrid.Visibility = Visibility.Hidden;
            OpenRepoGrid.Visibility = Visibility.Hidden;
        }
		private void Go_To_CommitHistoryGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            if (true)
            {
                openActivePath();
                autoIt.WinActivate("Administrator: C:\\Windows\\system32\\cmd.exe");
                wait(10);
                string cmd = "git log";
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            }
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Visible;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositoryCreationGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Visible;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositorySelectGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Visible;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_CommitGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Visible;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_LoginGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Visible;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_PullGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Visible;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_OpenRepoGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Visible;
		}
		private void Go_To_RepositoryMainGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Visible;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
		}

		private void RedXButtonClick(object sender, System.Windows.RoutedEventArgs e)
		{
			DeleteRepoBoxGrid.Visibility = Visibility.Visible;
		}
	}
}