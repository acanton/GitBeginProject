﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LibGit2Sharp;

namespace GitBegin
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
    
	public partial class MainWindow : Window
	{
        string activeRepoPath = "";
		public MainWindow()
		{
			this.InitializeComponent();
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}

		private void Button_Mouse_Enter(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: Add event handler implementation here.
		}
		private void Go_To_MainMenuGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
        private void Create_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            string s = FolderPathTextBox.Text;
            activeRepoPath = s;
            bool bareRepo = (bool)BareRepo.IsChecked;
            if (bareRepo == null)
                bareRepo = false;
            Create_Repo(FolderPathTextBox.Text, RepoNameTextBox.Text, bareRepo);
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void Commit_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            string message = FolderPathTextBox1.Text;
            using (var repo = new Repository(activeRepoPath))
            {

                // Create the committer's signature and commit
                Signature author = new Signature("Default User", "email@email.com", DateTime.Now);
                Signature committer = author;
                   
                // Commit to the repository
                Commit commit = repo.Commit(message, author, committer);
            }

        }
        private void Create_Repo(string path, string name, bool bareRepo)
        {
            string rootedPath = Repository.Init(path + "\\" + name, bareRepo);

            Console.WriteLine(rootedPath);
        }
		private void Go_To_CommitHistoryGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Visible;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositoryCreationGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Visible;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositorySelectGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Visible;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_CommitGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Visible;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_LoginGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Visible;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_PullGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Visible;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_OpenRepoGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Visible;
		}
		private void Go_To_RepositoryMainGrid(object sender, System.Windows.RoutedEventArgs e)
		{
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Visible;
			OpenRepoGrid.Visibility = Visibility.Hidden;
		}
	}
}