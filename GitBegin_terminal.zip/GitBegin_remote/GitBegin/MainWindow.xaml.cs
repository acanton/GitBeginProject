﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NGit;
using NGit.Api;
using NGit.Transport;
using AutoItX3Lib;


namespace GitBegin
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
    
	public partial class MainWindow : Window
	{
        string activeRepoPath = "";
        NGit.Api.Git repository;
        string activeURI = "";
        bool terminalMode = false;
        bool tutorialMode = false;
        bool commandMode = false;
        AutoItX3 autoIt = new AutoItX3();

		public MainWindow()
		{
			this.InitializeComponent();
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
			SettingsMenuGrid.Visibility = Visibility.Hidden;
			HelpGrid.Visibility = Visibility.Hidden;
            autoIt.AutoItSetOption("WinTitleMatchMode", 2);
		}

		private void Button_Mouse_Enter(object sender, System.Windows.RoutedEventArgs e)
		{
			// TODO: Add event handler implementation here.
		}
		private void Go_To_MainMenuGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Visible;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
        private void Clone_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            //string rootedPath = Repository.Init(path + "\\" + name, bareRepo);
            string cloneDestination = FolderPathTextBox3.Text;
            if (terminalMode)
            {
                checkTerminal();
                autoIt.WinActivate("cmd.exe");
                autoIt.WinWaitActive("cmd.exe");
                activeRepoPath = cloneDestination;
                string cmd = "git clone " + activeURI + " " + cloneDestination;
                autoIt.Send(cmd + "\r");
                //autoIt.WinActivate("MainWindow");
            }
            else
            {


                var credentials = new UsernamePasswordCredentialsProvider("michael4243", "surprises0");
                CredentialsProvider.SetDefault(credentials);
                // Let's clone the NGit repository
                var clone = Git.CloneRepository()
                    .SetDirectory(@activeRepoPath)
                    .SetURI(activeURI);

                // Execute and return the repository object we'll use for further commands
                repository = clone.Call();
                //Console.WriteLine(rootedPath);
                Go_To_RepositoryMainGrid(sender, e);
            }
            
        }
        private void Done_Cloning(object sender, System.Windows.RoutedEventArgs e)
        {
            openActivePath();
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void Open_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            string s =  FolderPathTextBox4.Text + "/" + RepoNameTextBox1.Text+  ".git";
            activeURI = s;
            if (terminalMode)
            {
                activeRepoPath = FolderPathTextBox4.Text;
                if (s.StartsWith("C:\\"))
                {
                    openActivePath();
                }
                
            }
            else
            {
                var credentials = new UsernamePasswordCredentialsProvider("michael4243", "surprises0");
                CredentialsProvider.SetDefault(credentials);
            }
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void Create_Repo_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            string s = FolderPathTextBox.Text;
            activeRepoPath = s;
            activeURI = s;
            bool bareRepo = (bool)BareRepo.IsChecked;
            //Create_Repo(FolderPathTextBox.Text, RepoNameTextBox.Text, bareRepo);

            if (terminalMode)
            {
                checkTerminal();
                autoIt.WinActivate("cmd.exe");
                autoIt.WinWaitActive("cmd.exe");
                string cmd = "git init";
                if (bareRepo)
                    cmd += " --bare";
                autoIt.Send("mkdir " + activeRepoPath + "\r");
                autoIt.Send("cd " + activeRepoPath + "\r");
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            }
            else
            {
                var clone = Git.Init()
                    .SetDirectory(@activeRepoPath)
                    .SetBare(bareRepo);

                // Execute and return the repository object we'll use for further commands
                repository = clone.Call();
            }
            Go_To_RepositoryMainGrid(sender, e);
        }
        private void Commit_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            var author = new PersonIdent("Michael", "mkell49@lsu.edu");
            string message = FolderPathTextBox1.Text;

            if (terminalMode)
            {
                //openActivePath();
                autoIt.WinActivate("cmd.exe");
                autoIt.Send("git commit -m \"" + activeRepoPath + "\"" + "\r");
                autoIt.WinActivate("MainWindow");
            }
            else
            {
                var commit = repository.Commit()
                    .SetMessage(message)
                    .SetAuthor(author)
                    .SetAll(true) // This automatically stages modified and deleted files
                    .Call();

                // Our new commit's hash
                var hash = commit.Id;
                //using (var repo = new Repository(activeRepoPath))
                //{

                // Create the committer's signature and commit
                //Signature author = new Signature("Default User", "email@email.com", DateTime.Now);
                //Signature committer = author;

                // Commit to the repository
                //Commit commit = repo.Commit(message, author, committer);
                //}
            }
            Go_To_RepositoryMainGrid(sender, e);
        }

        private void Push_Button(object sender, System.Windows.RoutedEventArgs e)
        {
            if (terminalMode)
            {
                openActivePath();
                string cmd = "git push";
                autoIt.Send(cmd + "\r");
                autoIt.WinActivate("MainWindow");
            }
            else
            {
                var push = repository.Push().Call();
            }
        }
        private void checkTerminal()
        {
            if (autoIt.WinExists("cmd.exe") == 0)
            {
                System.Diagnostics.Process.Start("C:\\Windows\\system32\\cmd.exe");
            }
        }
        private void openActivePath()
        {
            checkTerminal();
            autoIt.WinActivate("cmd.exe");
            autoIt.WinWaitActive("cmd.exe");
            string cmd = "cd " + activeRepoPath;
            autoIt.Send(cmd + "\r");
            autoIt.WinActivate("MainWindow");
        }
        private void Toggle_Terminal_Mode(object sender, System.Windows.RoutedEventArgs e)
        {
            terminalMode = !terminalMode;
            if (terminalMode)
            {
                TerminalButton.Content = "Disable Terminal Window";
                checkTerminal();
            }
            else
            {
                TerminalButton.Content = "Use Terminal Window";
            }
        }
        private void Toggle_Tutorial_Mode(object sender, System.Windows.RoutedEventArgs e)
        {
            terminalMode = !terminalMode;
            if (terminalMode)
            {
                TutorialButton.Content = "Turn Tutorial Mode Off";
            }
            else
            {
                TutorialButton.Content = "Turn Tutorial Mode On";
            }
        }
        private void Toggle_Command_Mode(object sender, System.Windows.RoutedEventArgs e)
        {
            terminalMode = !terminalMode;
            if (terminalMode)
            {
                CommandButton.Content = "Turn Command Mode Off";
            }
            else
            {
                CommandButton.Content = "Turn Command Mode On";
            }
        }
        private void Go_To_SettingsGrid(object sender, System.Windows.RoutedEventArgs e)
        {
            FileViewerGrid.Visibility = Visibility.Hidden;
            MainMenuGrid.Visibility = Visibility.Hidden;
            CommitHistoryGrid.Visibility = Visibility.Hidden;
            RepositoryCreationGrid.Visibility = Visibility.Hidden;
            RepositorySelectGrid.Visibility = Visibility.Hidden;
            CommitGrid.Visibility = Visibility.Hidden;
            LoginGrid.Visibility = Visibility.Hidden;
            PullGrid.Visibility = Visibility.Hidden;
            RepositoryMainGrid.Visibility = Visibility.Hidden;
            OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Visible;
        }
        private void Go_To_FileViewerGrid(object sender, System.Windows.RoutedEventArgs e)
        {
            FileViewerGrid.Visibility = Visibility.Visible;
            MainMenuGrid.Visibility = Visibility.Hidden;
            CommitHistoryGrid.Visibility = Visibility.Hidden;
            RepositoryCreationGrid.Visibility = Visibility.Hidden;
            RepositorySelectGrid.Visibility = Visibility.Hidden;
            CommitGrid.Visibility = Visibility.Hidden;
            LoginGrid.Visibility = Visibility.Hidden;
            PullGrid.Visibility = Visibility.Hidden;
            RepositoryMainGrid.Visibility = Visibility.Hidden;
            OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
        }
		private void Go_To_CommitHistoryGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Visible;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositoryCreationGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Visible;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositorySelectGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Visible;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_CommitGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Visible;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_LoginGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Visible;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_PullGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Visible;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_OpenRepoGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Hidden;
			OpenRepoGrid.Visibility = Visibility.Visible;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}
		private void Go_To_RepositoryMainGrid(object sender, System.Windows.RoutedEventArgs e)
		{
            FileViewerGrid.Visibility = Visibility.Hidden;
			MainMenuGrid.Visibility = Visibility.Hidden;
			CommitHistoryGrid.Visibility = Visibility.Hidden;
			RepositoryCreationGrid.Visibility = Visibility.Hidden;
			RepositorySelectGrid.Visibility = Visibility.Hidden;
			CommitGrid.Visibility = Visibility.Hidden;
			LoginGrid.Visibility = Visibility.Hidden;
			PullGrid.Visibility = Visibility.Hidden;
			RepositoryMainGrid.Visibility = Visibility.Visible;
			OpenRepoGrid.Visibility = Visibility.Hidden;
			DeleteRepoBoxGrid.Visibility = Visibility.Hidden;
            SettingsMenuGrid.Visibility = Visibility.Hidden;
		}

		private void RedXButtonClick(object sender, System.Windows.RoutedEventArgs e)
		{
			DeleteRepoBoxGrid.Visibility = Visibility.Visible;
		}
	}
}