package com.example.git_mob;


import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class HomeFragment extends Fragment implements OnClickListener {

	public HomeFragment() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	 @Override
	 public View onCreateView(LayoutInflater inflater, ViewGroup container,
			 Bundle savedInstanceState) {	  
		
		 View rootView = inflater.inflate(R.layout.home_main, container, false);
		 Button open_repo = (Button) rootView.findViewById(R.id.open_repo);
		 Button create_repo = (Button) rootView.findViewById(R.id.create_repo);
		 	
	     
	     open_repo.setOnClickListener(this);  
	     create_repo.setOnClickListener(this);
		 
		 return rootView;
	    }



	@Override
	public void onClick(View v) {
		Fragment fragment = null;
		
		switch (v.getId()) {
		
        case R.id.open_repo:
   
        		fragment = new ListInfo();
        	break;
        case R.id.button_register:
        	break;
		
		}
		if (fragment != null) {
			
            FragmentManager fragmentManager = getFragmentManager();
            // transaction of fragment actually starts here
            fragmentManager.beginTransaction()
                    .replace(R.id.content_frame, fragment).commit();
 
           
            
        } else {
            // error in creating fragment
            Log.e("MainActivity", "Error in creating fragment");
        }
		
	}
	 
	 

}
